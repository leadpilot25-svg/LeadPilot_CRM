import { useState } from 'react';
import { Lead } from '../types';
import { X, User, Phone, Mail, MapPin, Search } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface AddProps {
  onClose: () => void;
  onSave: (lead: Lead) => void;
}

export function AddLeadModal({ onClose, onSave }: AddProps) {

  // 🔥 GET LOGGED USER
  const user = JSON.parse(localStorage.getItem("user") || "{}");

  const [formData, setFormData] = useState<Partial<Lead>>({
    firstName: '',
    lastName: '',
    phone: '',
    email: '',
    propType: '',
    budget: '',
    location: '',
    remarks: '',
    status: 'New',
    followUp: new Date().toISOString().split('T')[0],
    source: 'Website',
    agentName: user.name || 'Agent',
  });

  const agents = ["Agent", "Agent A", "Agent B"]; // 🔥 YOU CAN EDIT

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const leadData = {
      ...formData,
      timestamp: new Date().toISOString(),
      callDone: 'No',
      status: 'New',

      // 🔥 AUTO ASSIGN LOGIC
      agentName: user.role === "agent"
        ? user.name
        : formData.agentName || "Unassigned",
    };

    await fetch("https://script.google.com/macros/s/AKfycbwkNhVGI9Te8mJ4ik6_NtVKfC1rywyxd-ETs3VWVg1Th3fijCj-604BMYb4OwNEOfODPA/exec", {
      method: "POST",
      body: JSON.stringify({
        action: "addLead",
        lead: leadData
      })
    });

    onSave(leadData as Lead);
    onClose();
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center">
        
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-black/40"
        />

        <motion.div 
          initial={{ translateY: '100%' }}
          animate={{ translateY: 0 }}
          exit={{ translateY: '100%' }}
          className="relative bg-white w-full max-w-lg rounded-t-3xl sm:rounded-3xl p-6 shadow-2xl overflow-y-auto max-h-[90vh]"
        >

          <div className="flex justify-between mb-6">
            <h2 className="text-xl font-black">Add New Lead</h2>
            <button onClick={onClose}>
              <X />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">

            <Input label="First Name" icon={User} value={formData.firstName}
              onChange={v => setFormData({ ...formData, firstName: v })} required />

            <Input label="Phone" icon={Phone} value={formData.phone}
              onChange={v => setFormData({ ...formData, phone: v })} required />

            <Input label="Email" icon={Mail} value={formData.email}
              onChange={v => setFormData({ ...formData, email: v })} />

            <Input label="Location" icon={MapPin} value={formData.location}
              onChange={v => setFormData({ ...formData, location: v })} />

            {/* 🔥 AGENT DROPDOWN (ADMIN ONLY) */}
            {user.role === "admin" && (
              <div>
                <label className="text-xs text-gray-400">Assign Agent</label>
                <select
                  value={formData.agentName}
                  onChange={e => setFormData({ ...formData, agentName: e.target.value })}
                  className="w-full bg-gray-50 border rounded-xl py-3 px-4"
                >
                  {agents.map(a => (
                    <option key={a} value={a}>{a}</option>
                  ))}
                </select>
              </div>
            )}

            {/* FOLLOW UP */}
            <input
              type="date"
              value={formData.followUp}
              onChange={e => setFormData({ ...formData, followUp: e.target.value })}
              className="w-full bg-gray-50 border rounded-xl py-3 px-4"
            />

            <button
              type="submit"
              className="w-full bg-[#059669] text-white py-3 rounded-xl font-bold"
            >
              CREATE LEAD
            </button>

          </form>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}

/* INPUT */
function Input({ label, icon: Icon, value, onChange, required = false }: any) {
  return (
    <div>
      <label className="text-xs text-gray-400">{label}</label>
      <div className="flex items-center bg-gray-50 border rounded-xl px-3">
        <Icon size={16} className="text-gray-400" />
        <input
          value={value || ''}
          onChange={e => onChange(e.target.value)}
          required={required}
          className="w-full p-3 bg-transparent outline-none"
        />
      </div>
    </div>
  );
}