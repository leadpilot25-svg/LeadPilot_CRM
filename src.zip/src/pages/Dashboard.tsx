import { useState, useMemo, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Header } from '../components/Header';
import { BottomNav } from '../components/BottomNav';
import { LeadCard } from '../components/LeadCard';
import { useLeads } from '../hooks/useLeads';
import { Search, Loader2 } from 'lucide-react';
import { Lead } from '../types';
import { cn } from '../lib/utils';
import { UpdateLeadModal } from '../components/UpdateLeadModal';
import { AddLeadModal } from '../components/AddLeadModal';

export default function Dashboard() {
  const { leads, loading, refreshLeads, updateLead, addLead } = useLeads();

  const [searchParams, setSearchParams] = useSearchParams();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  const filterParam = searchParams.get('filter') || 'All';
  const today = new Date().toISOString().split('T')[0];

  const setFilter = (filter: string) => {
    setSearchParams({ filter });
  };

  /* SELECT */
  const toggleSelect = (id: string) => {
    setSelectedIds(prev =>
      prev.includes(id)
        ? prev.filter(i => i !== id)
        : [...prev, id]
    );
  };

  /* BULK ASSIGN */
  const bulkAssign = (agent: string) => {
    leads.forEach(lead => {
      if (selectedIds.includes(lead.id)) {
        updateLead({ ...lead, agentName: agent });
      }
    });

    setSelectedIds([]);
    alert(`Assigned to ${agent}`);
  };

  /* STATS */
  const stats = useMemo(() => ({
    overdue: leads.filter(l => l.followUp && l.followUp < today && l.status !== 'Done').length,
    today: leads.filter(l => l.followUp === today && l.status !== 'Done').length,
    upcoming: leads.filter(l => l.followUp && l.followUp > today && l.status !== 'Done').length,
    done: leads.filter(l => l.status === 'Done').length,
    total: leads.length,
  }), [leads]);

  /* ALERT */
  const todayLeads = useMemo(() => {
    return leads.filter(l => l.followUp === today && l.status !== 'Done');
  }, [leads]);

  useEffect(() => {
    const shown = localStorage.getItem("followup_alert_date");

    if (todayLeads.length > 0 && shown !== today) {
      setTimeout(() => {
        alert(`🔔 You have ${todayLeads.length} follow-ups today`);
      }, 500);

      localStorage.setItem("followup_alert_date", today);
    }
  }, [todayLeads]);

  /* FILTER */
  const filteredLeads = useMemo(() => {
    let result = [...leads];

    // 🔥 REMOVE ADMIN FAKE LEADS
    result = result.filter(
      l => (l.firstName || "").toLowerCase().trim() !== "admin"
    );

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(l =>
        (l.firstName?.toLowerCase() || '').includes(q) ||
        (l.lastName?.toLowerCase() || '').includes(q) ||
        (l.phone || '').includes(q)
      );
    }

    if (filterParam === 'Today') {
      result = result.filter(l => l.followUp === today && l.status !== 'Done');
    }

    if (filterParam === 'Overdue') {
      result = result.filter(l => l.followUp && l.followUp < today && l.status !== 'Done');
    }

    if (filterParam === 'Upcoming') {
      result = result.filter(l => l.followUp && l.followUp > today && l.status !== 'Done');
    }

    if (filterParam === 'Done') {
      result = result.filter(l => l.status === 'Done');
    }

    return result;
  }, [leads, searchQuery, filterParam]);

  return (
    <div className="h-screen flex flex-col bg-[#f5f7fb]">

      <Header onAddLead={() => setIsAddModalOpen(true)} />

      {/* BULK BAR */}
      {selectedIds.length > 0 && (
        <div className="mx-3 mt-2 bg-white p-3 rounded-xl shadow flex justify-between items-center">
          <span className="text-sm font-semibold">
            {selectedIds.length} selected
          </span>

          <div className="flex gap-2">
            <button
              onClick={() => bulkAssign("Agent A")}
              className="bg-emerald-500 text-white px-3 py-1 rounded text-xs"
            >
              Assign A
            </button>

            <button
              onClick={() => bulkAssign("Agent B")}
              className="bg-blue-500 text-white px-3 py-1 rounded text-xs"
            >
              Assign B
            </button>
          </div>
        </div>
      )}

      {/* ALERT */}
      {todayLeads.length > 0 && (
        <div className="mx-3 mt-2 bg-yellow-100 text-yellow-800 px-3 py-2 rounded-xl text-sm font-semibold">
          🔔 You have {todayLeads.length} follow-ups today
        </div>
      )}

      {/* FILTER */}
      <div className="bg-[#f5f7fb] z-40">

        <div className="px-3 mt-3 grid grid-cols-2 gap-3">
          <StatCard label="Tasks Today" value={stats.today} onClick={() => setFilter('Today')} />
          <StatCard label="Overdue" value={stats.overdue} onClick={() => setFilter('Overdue')} />
          <StatCard label="Total Leads" value={stats.total} onClick={() => setFilter('All')} />
          <StatCard label="Upcoming" value={stats.upcoming} onClick={() => setFilter('Upcoming')} />
        </div>

        <div className="px-3 mt-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input
              type="text"
              placeholder="Search leads..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white border rounded-xl py-2.5 pl-10 pr-4 text-sm"
            />
          </div>
        </div>

        <div className="px-3 mt-3 flex gap-2 overflow-x-auto pb-2">
          <Tab label="All" isActive={filterParam === 'All'} onClick={() => setFilter('All')} />
          <Tab label="Today" isActive={filterParam === 'Today'} onClick={() => setFilter('Today')} />
          <Tab label="Overdue" isActive={filterParam === 'Overdue'} onClick={() => setFilter('Overdue')} />
          <Tab label="Upcoming" isActive={filterParam === 'Upcoming'} onClick={() => setFilter('Upcoming')} />
          <Tab label="Done" isActive={filterParam === 'Done'} onClick={() => setFilter('Done')} />
        </div>

      </div>

      {/* LEADS */}
      <div className="flex-1 overflow-y-auto px-3 pt-2 pb-24">

        {loading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="animate-spin" />
          </div>
        ) : filteredLeads.length > 0 ? (
          filteredLeads.map((lead, idx) => (

            <div key={idx} className="mb-3 space-y-2">

              {/* ✅ FIXED NAME DISPLAY */}
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={selectedIds.includes(lead.id)}
                  onChange={() => toggleSelect(lead.id)}
                />

                <span className="text-sm font-medium text-gray-700">
                  {lead.firstName || "No Name"}
                  <span className="text-xs text-gray-400 ml-2">
                    ({lead.agentName || "Unassigned"})
                  </span>
                </span>
              </div>

              <LeadCard 
                lead={lead} 
                onUpdate={setSelectedLead} 
              />

              {/* ASSIGN */}
              <div className="bg-white border rounded-xl p-2 flex justify-between items-center">
                <span className="text-xs text-gray-500">
                  Assigned: {lead.agentName || "Unassigned"}
                </span>

                <select
                  className="text-xs border rounded px-2 py-1"
                  value={lead.agentName || ""}
                  onChange={(e) => {
                    updateLead({ ...lead, agentName: e.target.value });
                  }}
                >
                  <option value="">Assign</option>
                  <option value="Agent A">Agent A</option>
                  <option value="Agent B">Agent B</option>
                </select>
              </div>

            </div>

          ))
        ) : (
          <div className="text-center py-20 text-gray-500">
            No leads found
          </div>
        )}

      </div>

      <BottomNav onRefresh={refreshLeads} onAddLead={() => setIsAddModalOpen(true)} />

      {selectedLead && (
        <UpdateLeadModal
          lead={selectedLead}
          onClose={() => setSelectedLead(null)}
          onSave={updateLead}
        />
      )}

      {isAddModalOpen && (
        <AddLeadModal
          onClose={() => setIsAddModalOpen(false)}
          onSave={addLead}
        />
      )}

    </div>
  );
}

/* COMPONENTS */
function StatCard({ label, value, onClick }: any) {
  return (
    <div onClick={onClick} className="bg-white rounded-xl p-3 shadow border cursor-pointer">
      <div className="text-xl font-bold">{value}</div>
      <div className="text-xs text-gray-500">{label}</div>
    </div>
  );
}

function Tab({ label, isActive, onClick }: any) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "px-3 py-1 rounded-full text-xs",
        isActive ? "bg-emerald-500 text-white" : "bg-white border text-gray-500"
      )}
    >
      {label}
    </button>
  );
}